#pragma once
namespace Eloquent {
    namespace Projects {
        class WifiIndoorPositioning {
            public:
                float features[51] = {0};
                /**
                * Get feature vector
                */
                float* scan() {
                    uint8_t numNetworks = WiFi.scanNetworks();

                    for (uint8_t i = 0; i < 51; i++) {
                        features[i] = 0;
                    }

                    for (uint8_t i = 0; i < numNetworks; i++) {
                        int featureIdx = ssidToFeatureIdx(WiFi.SSID(i));

                        if (featureIdx >= 0) {
                            features[featureIdx] = WiFi.RSSI(i);
                        }
                    }

                    return features;
                }

            protected:
                /**
                * Convert SSID to featureIdx
                */
                int ssidToFeatureIdx(String ssid) {
                    if (ssid.equals("AndroidAP5565"))
                    return 0;

                    if (ssid.equals("Argayhome2.4"))
                    return 1;

                    if (ssid.equals("BodiNappali 2.4"))
                    return 2;

                    if (ssid.equals("C10-C8-B18A4"))
                    return 3;

                    if (ssid.equals("C10-C8-B18B9"))
                    return 4;

                    if (ssid.equals("ClausCorth50"))
                    return 5;

                    if (ssid.equals("Combino2013"))
                    return 6;

                    if (ssid.equals("Fort William"))
                    return 7;

                    if (ssid.equals("Galaxy A4045DB"))
                    return 8;

                    if (ssid.equals("Guests-Telekom-5ba7a0"))
                    return 9;

                    if (ssid.equals("HUAWEI_B818_0CE2"))
                    return 10;

                    if (ssid.equals("Hege_2.4"))
                    return 11;

                    if (ssid.equals("Honey Tiger"))
                    return 12;

                    if (ssid.equals("HotspotAA75"))
                    return 13;

                    if (ssid.equals("I ragazzi della via Pal"))
                    return 14;

                    if (ssid.equals("IgniteNet-2.4G"))
                    return 15;

                    if (ssid.equals("MPK Hotspot"))
                    return 16;

                    if (ssid.equals("MPK Hotspot 70"))
                    return 17;

                    if (ssid.equals("MPK Public"))
                    return 18;

                    if (ssid.equals("MPK Support"))
                    return 19;

                    if (ssid.equals("MPK Vendeg"))
                    return 20;

                    if (ssid.equals("MikroTik-ABA37E"))
                    return 21;

                    if (ssid.equals("TP-Link_BD8A"))
                    return 22;

                    if (ssid.equals("Telekom-1f32e0"))
                    return 23;

                    if (ssid.equals("Telekom-2NDSSID"))
                    return 24;

                    if (ssid.equals("Telekom-3774ce-2.4GHz"))
                    return 25;

                    if (ssid.equals("Telekom-4d7fd0"))
                    return 26;

                    if (ssid.equals("Telekom-56b1d0"))
                    return 27;

                    if (ssid.equals("Telekom-571a78"))
                    return 28;

                    if (ssid.equals("Telekom-7437b9-2.4GHz"))
                    return 29;

                    if (ssid.equals("Telekom-807ead-2.4GHz"))
                    return 30;

                    if (ssid.equals("Telekom-9451d0"))
                    return 31;

                    if (ssid.equals("Telekom-9e9089-2.4GHz"))
                    return 32;

                    if (ssid.equals("Telekom-a06324-2.4GHz"))
                    return 33;

                    if (ssid.equals("Telekom-bb6ed3-2.4GHz"))
                    return 34;

                    if (ssid.equals("Telekom-d7e050"))
                    return 35;

                    if (ssid.equals("Telekom-d9b288"))
                    return 36;

                    if (ssid.equals("Telekom-da0268"))
                    return 37;

                    if (ssid.equals("UPC2195A8D"))
                    return 38;

                    if (ssid.equals("UPC2AD4C8"))
                    return 39;

                    if (ssid.equals("UPC5087788"))
                    return 40;

                    if (ssid.equals("UPC5140807"))
                    return 41;

                    if (ssid.equals("UPC5459663"))
                    return 42;

                    if (ssid.equals("UPC8492FAE"))
                    return 43;

                    if (ssid.equals("UPC9212101"))
                    return 44;

                    if (ssid.equals("UPCBCE9E4A"))
                    return 45;

                    if (ssid.equals("Vodafone-4CC5"))
                    return 46;

                    if (ssid.equals("Vodafone-C4C6"))
                    return 47;

                    if (ssid.equals("WARRIOR"))
                    return 48;

                    if (ssid.equals("ZH-Wn_SAMER_GSM"))
                    return 49;

                    if (ssid.equals("c51cbc"))
                    return 50;

                    return -1;
                }
            };
        }
    }