#pragma once
#include <cstdarg>
namespace Jonascsantos {
    namespace ML {
        namespace Port {
            class DecisionTree {
                public:
                    /**
                    * Predict class for features vector
                    */
                    int predict(float *x) {
                        if (x[62] <= -73.0) {
                            if (x[65] <= -63.5) {
                                if (x[32] <= -43.5) {
                                    return 0;
                                }

                                else {
                                    return 1;
                                }
                            }

                            else {
                                return 0;
                            }
                        }

                        else {
                            if (x[43] <= -41.0) {
                                if (x[62] <= -50.5) {
                                    if (x[69] <= -92.5) {
                                        if (x[47] <= -85.5) {
                                            return 2;
                                        }

                                        else {
                                            return 1;
                                        }
                                    }

                                    else {
                                        return 2;
                                    }
                                }

                                else {
                                    if (x[43] <= -86.5) {
                                        return 1;
                                    }

                                    else {
                                        return 2;
                                    }
                                }
                            }

                            else {
                                if (x[0] <= -42.5) {
                                    if (x[0] <= -89.5) {
                                        return 1;
                                    }

                                    else {
                                        return 2;
                                    }
                                }

                                else {
                                    if (x[62] <= -18.0) {
                                        if (x[65] <= -88.5) {
                                            return 2;
                                        }

                                        else {
                                            return 1;
                                        }
                                    }

                                    else {
                                        return 0;
                                    }
                                }
                            }
                        }
                    }

                    /**
                    * Predict readable class name
                    */
                    const char* predictLabel(float *x) {
                        return idxToLabel(predict(x));
                    }

                    /**
                    * Convert class idx to readable name
                    */
                    const char* idxToLabel(uint8_t classIdx) {
                        switch (classIdx) {
                            case 0:
                            return "Bedroom";
                            case 1:
                            return "Hall";
                            case 2:
                            return "Kitchen";
                            default:
                            return "Houston we have a problem";
                        }
                    }

                protected:
                };
            }
        }
    }
